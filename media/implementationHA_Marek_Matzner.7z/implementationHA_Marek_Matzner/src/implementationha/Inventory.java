/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationha;

/**
 *  Klasse zur Uebung, die ein Inventar beschreibt
 * @author q1.10matzner
 * @version 1.0
 */
public class Inventory {
    /**
     * Vorhandene Items
     * Gewicht des Inventarinhalts
     * Maximal erlaubtes Gewicht fuer Inhalt
     */
    private Item[] content = new Item[5];
    private double weight;
    private double maxweight;
    
    /**
     * Konstruktor des Inventars, das Inventar wird beim erstellen geleert
     */
    public Inventory() {
        for(int i=0; i<content.length;i++) {
            content[i] = null;
        }
        System.out.println("Inventar geleert!");
    }
    
    /**
     * Suchen von einem bestimmten Item im Inventar
     * @param i das zu suchende Item
     * @return index des zu suchenden Items im Inventar
     */
    public int searchContent(Item i) {
        int index  = 0;
        for(int ii = 0; ii < content.length; ii++) {
            if(content[ii] == i) {
                index = ii;
                System.out.println("Gefunden!"); 
                break;
            } else {
                return -1;
            }
        }
        return index;
    }

    /**
     * hinzufuegen von einem Item ins Inventar
     * @param i das hinzuzufuegende Item
     */
    public void addContent(Item i) {
        if(i!=null){
            for(int ii = 0; ii < content.length; ii++) {
                if(content[ii] == null) {
                    content[ii] = i;
                    this.setWeight(i.getWeight());
                    System.out.println("Hinzugefuegt!");
                    break;
                } else {
                    System.out.println("Kein Platz Mehr!");
                }
            }
        }
    }
    
    /**
     * entfernen eines Items aus dem Inventar
     * @param i das zu entfernende Item
     */
    public void remContent(Item i) {
        Item rem = new Item("","",0);
        for(int ii = 0; ii < content.length; ii++) {
            if(content[ii] == i) {
                content[ii] = null;
                System.out.println("Entfernt!"); 
                break;
            } else {
               System.out.println("Nicht gefunden!"); 
            }
        }
        
    }
    /**
     * Gibt die vorhandenen Items zurueck
     * @return alle vorh. Items
     */
    public Item[] getContent() {
        return content;
    }
    /**
     * Gibt das gewicht des Inventars zurueck
     * @return gewicht der Items im Inventar
     */
    public double getWeight() {
        return weight;
    }
    /**
     * Gibt das maximale Gewicht aller Items im Inventar zurueck
     * @return maximales Gewicht der Items im Inventar
     */
    public double getMaxweight() {
        return maxweight;
    }
    /**
     * Setzt den Inhalt des Inventars
     * @param content Array der Items die in das Inventar sollen
     */
    public void setContent(Item[] content) {
        this.content = content;
    }
    /**
     * Setzt das Gewicht der Items im Inventar
     * @param weight Gewicht der Items
     */
    public void setWeight(double weight) {
        this.weight = weight;
    }
    /**
     * Setzt das maximale Gewicht der Items im Inventar
     * @param maxweight maximales Gewicht
     */
    public void setMaxweight(double maxweight) {
        this.maxweight = maxweight;
    }
    /**
     * gibt alle Wichtigen Daten über das Objekt zurueck
     * @return wichtige Informationen zum Objekt
     */
    @Override
    public String toString() {
        return "Inventory{" + "content= " + content + ", weight= " + weight + ", maxweight= " + maxweight + '}';
    }
    
    
}
