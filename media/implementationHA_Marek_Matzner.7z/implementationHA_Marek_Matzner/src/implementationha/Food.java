/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationha;

/**
 *
 * @author Marek
 */
public class Food extends Item{
    private double health;
    Food(String n, String c, double w,double h) {
        super(n,c,w);
        health = h;
    }

    public void benutze(Player pl) {
        pl.setCurr_health(pl.getCurr_health() + health);
    }
    
    public double getHealth() {
        return health;
    }

    public void setHealth(double health) {
        this.health = health;
    }
    
    
}
