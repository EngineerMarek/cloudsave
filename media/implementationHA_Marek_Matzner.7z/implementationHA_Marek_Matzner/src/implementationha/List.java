/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationha;

/**
 * Implementierung der dynamischen Datenstruktur einer Liste
 * @author Marek
 * @version 1.1
 */
public class List {
    /**
     * erstes Element der Liste
     * aktuelles Element der Liste
     * letztes Element der Liste
     */
    private ListElement head,current,tail;

    /**
     * Konstruktor der Liste
     * @param start erstes Element der Liste
     */
    public List(ListElement start) {
        //Item start = new Item("","",0.0);
        head = start;
        current = head;
    }
    
    /*
    public List(Item start) {
        //Item start = new Item("","",0.0);
        head = new ListElement(start);
        current = head;
    }
    */
    /**
     * fuegt ein neues Element in der Liste hinzu
     * @param o das hinzuzufügene Item
     */
    public void addItem(Item o) {
        ListElement newLE = new ListElement(o);
        if(current.toString() == head.toString()) {
            head.setNext(newLE);
            head = newLE;
        } else {
            current.setNext(newLE);
            current = newLE;
        }
        
    }
    
    /**
     * findet ein Item an einem Index
     * @param n index des Items das gefunden werden soll
     * @return Item am index n
     */
    public Item get(int n) {
        if(findItemAtIndex(n) == null) {
            return null;
        }
        return findItemAtIndex(n).getO();
    }
    
    /**
     * findet ein Item am Index
     * @param n indes dex Items das gefunden werden soll
     * @return das gefundene Item am index n
     */
    private ListElement findItemAtIndex(int n) {
        if(n<0) 
            return null;
        
        ListElement iterator = head;
        for(int i = 0; i <n; i++) {
            if(iterator.hasNext()) {
                iterator = iterator.getNext();
            } else {
                return null;
            }
        }
        if(iterator == null) 
            return null;
        return iterator;
    }
    
    /**
     * loescht das Item am index
     * @param n index des zu loeschendes Items
     */
    public void deleteItem(int n) {
        if(n<1) {
            return;
        }
        if(this.findItemAtIndex(n) == null) {
            return;
        }
        ListElement toDelete = this.findItemAtIndex(n-1);
        toDelete.setNext(this.findItemAtIndex(n+1));
    }
    /**
     * 
     * loescht ein bestimmtes Item
     * @param m das zu loeschende Item
     */
    public void deleteItemByItem(Item m) {
        if(m == null) 
            System.out.println("falsche Eingabe");
        else {
            deleteItem(findItemByReference(m));
        }
        
    }
    /**
     * findet ein Item und gibt seinen Index zurueck
     * @param m das zu findende Item    
     * @return der Index des gefundenen Items
     */
    public int findItemByReference(Item m) {
        int zaeler = 0;
        ListElement iterator = this.findItemAtIndex(0);
        while(iterator.getO() != m) {
            zaeler++;
            iterator = iterator.getNext();
        }
        return zaeler;
    }
    /**
     * gibt die wichtigen Eigenschaften jedes Elements in der Liste aus
     */
    public void printAll() {
        ListElement iterator = this.findItemAtIndex(0);
        while(iterator != null) {
            System.out.println(iterator.getO().toString());
            iterator = iterator.getNext();
        }
    }
    
    /**
     * Gibt das erste Element der Liste zurueck
     * @return erstes Element der Lsite
     */
    public ListElement getHead() {
        return head;
    }
    /**
     * Gibt das aktuelle Element der Liste zurueck
     * @return aktuelle Element der Lsite
     */
    public ListElement getCurrent() {
        return current;
    }
    /**
     * Gibt das letzte Element der Liste zurueck
     * @return letzte Element der Lsite
     */
    public ListElement getTail() {
        return tail;
    }

     /**
     * setzte das erste Element der Liste
     * @param head erstes Element der Lsite
     */
    public void setHead(ListElement head) {
        this.head = head;
    }
    /**
     * setzte das aktuelle Element der Liste
     * @param current aktuelles Element der Lsite
     */
    public void setCurrent(ListElement current) {
        this.current = current;
    }
    /**
     * setzte das letzte Element der Liste
     * @param tail letztes Element der Lsite
     */
    public void setTail(ListElement tail) {
        this.tail = tail;
    }

    /**
     * gibt alle Wichtigen Daten über das Objekt zurueck
     * @return wichtige Informationen zum Objekt
     */
    @Override
    public String toString() {
        return "List{" + "head=" + head + ", current=" + current + ", tail=" + tail + '}';
    }

    /**
     * gibt alle Elemente in der Liste zurueck
     * @return alle Elemente der Liste
     */
    public String tellList() {
        return "List {" + head;
    }
}
