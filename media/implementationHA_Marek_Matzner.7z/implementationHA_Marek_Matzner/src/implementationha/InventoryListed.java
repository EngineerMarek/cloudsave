/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationha;

/**
 *  Klasse zur Uebung, die ein Inventar beschreibt
 * @author q1.10matzner
 * @version 1.0
 */
public class InventoryListed {
    /**
     * Vorhandene Items
     * Gewicht des Inventarinhalts
     * Maximal erlaubtes Gewicht fuer Inhalt
     */
    private List content;
    private double weight;
    private double maxweight;
    
    /**
     * Konstruktor des Inventars, das Inventar wird beim erstellen geleert
     * @param first das ertse Item des Inventars
     */
    public InventoryListed(Item first) {
        ListElement temp = new ListElement(first);
        content = new List();
        content.addItem(temp);
        System.out.println("Inventar erstellt!");
    }
    

    /**
     * Gibt die vorhandenen Items zurueck
     * @return alle vorh. Items
     */
    public List getContent() {
        return content;
    }
    /**
     * Gibt das gewicht des Inventars zurueck
     * @return gewicht der Items im Inventar
     */
    public double getWeight() {
        return weight;
    }
    /**
     * Gibt das maximale Gewicht aller Items im Inventar zurueck
     * @return maximales Gewicht der Items im Inventar
     */
    public double getMaxweight() {
        return maxweight;
    }
    /**
     * Setzt den Inhalt des Inventars
     * @param content Array der Items die in das Inventar sollen
     */
    public void setContent(List content) {
        this.content = content;
    }
    /**
     * Setzt das Gewicht der Items im Inventar
     * @param weight Gewicht der Items
     */
    public void setWeight(double weight) {
        this.weight = weight;
    }
    /**
     * Setzt das maximale Gewicht der Items im Inventar
     * @param maxweight maximales Gewicht
     */
    public void setMaxweight(double maxweight) {
        this.maxweight = maxweight;
    }
    /**
     * gibt alle Wichtigen Daten über das Objekt zurueck
     * @return wichtige Informationen zum Objekt
     */
    @Override
    public String toString() {
        return "Inventory{" + "content= " + content + ", weight= " + weight + ", maxweight= " + maxweight + '}';
    }
    
    
}
