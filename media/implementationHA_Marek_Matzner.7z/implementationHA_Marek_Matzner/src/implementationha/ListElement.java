/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationha;

/**
 * Implementation des ListElements der komplexen Datenstruktur Liste
 * @author Marek
 * @version 1.1
 */
public class ListElement {
    /**
     * Item; das gespeicherte Item im Element
     * next; zeiger auf das nachfolgende Element in der Liste
     */
    private Item o;
    private ListElement next;
    
    /**
     * Konstruktor des ListElements
     * @param o das zu speichernde Item
     */
    public ListElement(Item o) {
        this.o = o;
        next = null;
    }
    /**
     * methode zum ueberpruefen ob ein Element einen Nachfolger hat
     * @return ob ein Nachfolger existiert
     */
    public boolean hasNext() {
        if(this.next == null) {
            return false;
        } else {
            return true;
        }
    }
    /**
     * gibt das gespeicherte Item zurueck
     * @return das gespeicherte Item
     */
    public Item getO() {
        return o;
    }
    /**
     * gibt den Zeiger zum naechsten Element zurueck
     * @return Zeiger des Nächsten Elementes
     */
    public ListElement getNext() {
        return next;
    }
    /**
     * setzt das zu speichernde Element
     * @param o das zu speichernde Element
     */
    public void setO(Item o) {
        this.o = o;
    }
    /**
     * setzt den Zeiger zum naechsten Element
     * @param next Zeiger zum naechsten Element
     */
    public void setNext(ListElement next) {
        this.next = next;
    }
    /**
     * gibt alle Wichtigen Daten über das Objekt zurueck
     * @return wichtige Informationen zum Objekt
     */
    @Override
    public String toString() {
        return "ListElement{" + "o=" + o + ", next=" + next + '}';
    }
    
    
}
