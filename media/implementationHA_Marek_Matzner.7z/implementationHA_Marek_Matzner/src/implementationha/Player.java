/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationha;

/**
 *
 * @author Marek
 */
public class Player {
    private double curr_health;
    private double curr_armour;
    private double curr_attack;
    private double base_attack;
    
    public Player(double h, double ar, double at,double bat) {
        curr_health = h;
        curr_armour = ar;
        curr_attack = at;
        base_attack= bat;
    }

    public double getCurr_health() {
        return curr_health;
    }

    public void setCurr_health(double curr_health) {
        this.curr_health = curr_health;
    }

    public double getCurr_armour() {
        return curr_armour;
    }

    public void setCurr_armour(double curr_armour) {
        this.curr_armour = curr_armour;
    }

    public double getCurr_attack() {
        return curr_attack;
    }

    public void setCurr_attack(double curr_attack) {
        this.curr_attack = curr_attack;
    }

    public double getBase_attack() {
        return base_attack;
    }

    public void setBase_attack(double base_attack) {
        this.base_attack = base_attack;
    }
    
    
    
}
