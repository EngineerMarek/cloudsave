/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationha;

/**
 *
 * @author Marek
 */
public class Weapon extends Item{
    private double damage;
    Weapon(String n, String c, double w,double d) {
        super(n,c,w);
        damage = d;
    }

    public void benutze(Player pl) {
        pl.setCurr_attack(pl.getCurr_attack() + damage);
    }
    
    
    public double getDamage() {
        return damage;
    }

    public void setDamage(double damage) {
        this.damage = damage;
    }
    
}
