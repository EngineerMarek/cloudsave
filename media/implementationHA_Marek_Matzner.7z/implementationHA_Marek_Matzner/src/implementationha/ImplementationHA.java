/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationha;

/**
 *
 * @author Marek
 */
public class ImplementationHA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        implementationha.Armor myarm  = new Armor("Brustplatte","ein einfacher Schutz fuer die Brust",3.5,3.5);
        System.out.println(myarm.getName());
        
        implementationha.Weapon myweap  = new Weapon("Schwert","ein einfaches Schwert",3.5,5);
        System.out.println(myweap.getCapture());
    }
    
}
