/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationha;

/**
 *
 * @author Marek
 */
public class Armor extends Item {
    private double defense;
    Armor(String n, String c, double w,double d) {
        super(n,c,w);
        defense = d;
    }

    public void benutze(Player pl) {
        pl.setCurr_armour(pl.getCurr_armour() + defense);
    }
    
    public double getDefense() {
        return defense;
    }

    public void setDefense(double defense) {
        this.defense = defense;
    }
    
}
