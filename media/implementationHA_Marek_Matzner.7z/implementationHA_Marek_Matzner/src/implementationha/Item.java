/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementationha;

/**
 *
 * @author Marek
 * Eine Klasse als Uebung aus dem Spiel SchoolMania, die Gegenstaende darstellt
 * 
 * 
 */
public class Item {
    private String name,capture;
    private double weight;
    
    public Item(String n, String c, double w) {
        name = n;
        capture = c;
        weight = w;
    }

    
    
    public String getName() {
        return name;
    }

    public String getCapture() {
        return capture;
    }

    public double getWeight() {
        return weight;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCapture(String capture) {
        this.capture = capture;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
    
    
    
}
